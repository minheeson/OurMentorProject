package com.ourmentor.ymh.lck.smh.common;

/**
 * Created by ccei on 2016-02-15.
 */
public class JoinRoomData {
    int success;
    String name, username, room;
}
