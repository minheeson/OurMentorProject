package com.ourmentor.ymh.lck.smh.common;

/**
 * Created by lee on 16. 2. 14.
 */
public class ChatListData {
	String roomName = "error";
	String userName ;
	int userNo;

	public ChatListData() {

	}
	public ChatListData(String roomName) {
		this.roomName = roomName;
	}
}
