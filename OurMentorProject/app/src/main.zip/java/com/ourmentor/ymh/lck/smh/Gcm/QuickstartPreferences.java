package com.ourmentor.ymh.lck.smh.Gcm;

/**
 * Created by ccei on 2016-02-18.
 */
public class QuickstartPreferences {
    public static final String REGISTRATION_READY = "registrationReady";
    public static final String REGISTRATION_GENERATING = "registrationGenerating";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
}
