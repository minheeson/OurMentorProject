package com.ourmentor.ymh.lck.smh.fragment;

/**
 * Created by ccei on 2016-01-26.
 */
public class NaviItemData {
    public int navi_listview_imageId;
}
