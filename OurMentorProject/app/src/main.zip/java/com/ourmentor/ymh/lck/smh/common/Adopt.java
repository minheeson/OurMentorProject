package com.ourmentor.ymh.lck.smh.common;

/**
 * Created by ccei on 2016-02-18.
 */
public class Adopt {
    public int userNo;
    public int yorn;

    public Adopt() {

    }

    public Adopt(int userNo, int yorn) {
        this.userNo = userNo;
        this.yorn = yorn;
    }
}
