package com.ourmentor.ymh.lck.smh.common;

/**
 * Created by ccei on 2016-01-25.
 */
public class dbManager {
}
