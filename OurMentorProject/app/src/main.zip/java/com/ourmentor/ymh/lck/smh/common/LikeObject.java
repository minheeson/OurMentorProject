package com.ourmentor.ymh.lck.smh.common;

/**
 * Created by ccei on 2016-02-12.
 */
public class LikeObject {
    public int likeCnt;
    public int success_code;

    public LikeObject() {
    }

    public LikeObject(int likeCnt, int success_code) {
        this.likeCnt = likeCnt;
        this.success_code = success_code;
    }
}
